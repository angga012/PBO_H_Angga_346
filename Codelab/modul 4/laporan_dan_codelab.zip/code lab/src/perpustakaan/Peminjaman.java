
package perpustakaan;

interface Peminjaman {
    abstract void pinjamBuku(String judul);
    abstract void kembalikanBuku();

}
