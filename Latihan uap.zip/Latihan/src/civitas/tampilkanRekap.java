package civitas;

public interface tampilkanRekap {
    void tampilkanRekap();
}
